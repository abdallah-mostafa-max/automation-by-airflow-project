from airflow import DAG
from datetime import datetime, timedelta
from airflow.operators.python import PythonOperator
from airflow.operators.bash import BashOperator   # ✅ استيراد BashOperator

def print_number():
    print("Hello World")

with DAG(
    dag_id="dag1",
    start_date=datetime(2025, 9, 29),
    schedule_interval=timedelta(minutes=1),
    catchup=False
) as dag:
    
    task1 = PythonOperator(
        task_id="Python_task",
        python_callable=print_number
    )

    task_docker = BashOperator(
        task_id="docker",
        bash_command="ls -l -tmp"   # ✅ اسم الباراميتر الصحيح
    )

    task1 >> task_docker
